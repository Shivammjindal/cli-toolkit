#!/usr/bin/env python3
"""
MyKMS CLI - A standalone command-line interface for OpenBao (Vault).
Acts similarly to the AWS CLI (aws kms / aws secretsmanager).
"""
import os
import sys
import base64
import json

try:
    import click
    import hvac
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
except ImportError:
    print("Missing required libraries. Please install them by running:")
    print("pip install click hvac rich")
    sys.exit(1)

console = Console()

# --- Setup & Authentication ---

def get_client():
    """Initializes and authenticates the hvac client using environment variables."""
    url = os.environ.get("MYKMS_ADDR", "http://164.52.196.11:8200")
    token = os.environ.get("MYKMS_TOKEN")
    
    if not token:
        console.print("[red]Error: Authentication required.[/red]")
        console.print("Please set your OpenBao token as an environment variable:")
        console.print("  [bold cyan]export MYKMS_TOKEN='s.xxxxxxxxxxxxxxxxxxxx'[/bold cyan]")
        console.print("\nYou can optionally set the server address as well (default: http://164.52.196.11:8200):")
        console.print("  [bold cyan]export MYKMS_ADDR='http://your-server:8200'[/bold cyan]")
        sys.exit(1)

    client = hvac.Client(url=url, token=token)
    if not client.is_authenticated():
        console.print("[bold red]Error: Authentication failed. Your token is invalid or expired.[/bold red]")
        sys.exit(1)
        
    return client


# --- Root CLI Group ---

@click.group()
def cli():
    """MyKMS - A command line tool for Key and Secret management."""
    pass


# ==============================================================================
# KMS Commands (Transit Engine)
# ==============================================================================

@cli.group()
def kms():
    """Commands for Key Management Service (encrypt, decrypt, sign, etc.)"""
    pass

@kms.command("list-keys")
def kms_list_keys():
    """List all Customer Managed Keys."""
    client = get_client()
    try:
        response = client.secrets.transit.list_keys()
        keys = response["data"]["keys"]
        
        table = Table(title="KMS Customer Managed Keys")
        table.add_column("Key Name", style="cyan", no_wrap=True)
        
        for k in keys:
            if not k.endswith("/"):
                table.add_row(k)
        console.print(table)
    except hvac.exceptions.Forbidden:
        console.print("[red]Permission Denied: Your token does not have access to list keys.[/red]")
    except Exception as e:
        console.print(f"[red]Error listing keys: {e}[/red]")

@kms.command("encrypt")
@click.argument("key-id")
@click.argument("plaintext")
def kms_encrypt(key_id, plaintext):
    """Encrypt plaintext data using a KMS key."""
    client = get_client()
    try:
        encoded = base64.b64encode(plaintext.encode()).decode()
        response = client.secrets.transit.encrypt_data(name=key_id, plaintext=encoded)
        ciphertext = response["data"]["ciphertext"]
        
        panel = Panel(
            f"[bold green]Ciphertext:[/bold green]\n{ciphertext}",
            title=f"Encrypted with {key_id}",
            expand=False
        )
        console.print(panel)
    except Exception as e:
        console.print(f"[red]Error encrypting data: {e}[/red]")

@kms.command("decrypt")
@click.argument("key-id")
@click.argument("ciphertext")
def kms_decrypt(key_id, ciphertext):
    """Decrypt a ciphertext back to plaintext."""
    client = get_client()
    try:
        response = client.secrets.transit.decrypt_data(name=key_id, ciphertext=ciphertext)
        encoded = response["data"]["plaintext"]
        plaintext = base64.b64decode(encoded).decode()
        
        panel = Panel(
            f"[bold green]Plaintext:[/bold green]\n{plaintext}",
            title="Decryption Successful",
            expand=False
        )
        console.print(panel)
    except Exception as e:
        console.print(f"[red]Error decrypting data: {e}[/red]")


# ==============================================================================
# Secrets Manager Commands (KV v2 Engine)
# ==============================================================================

@cli.group()
def secretsmanager():
    """Commands for Secrets Manager (store, retrieve secrets)."""
    pass

@secretsmanager.command("list-secrets")
@click.option("--folder", default="", help="Optional folder path to list (e.g., 'prod/')")
def secrets_list(folder):
    """List stored secrets."""
    client = get_client()
    try:
        response = client.secrets.kv.v2.list_secrets(path=folder, mount_point="secret")
        secrets = response["data"]["keys"]
        
        table = Table(title=f"Secrets in '{folder}'" if folder else "All Secrets")
        table.add_column("Secret Name", style="cyan")
        table.add_column("Type", style="magenta")
        
        for s in secrets:
            if s.endswith("/"):
                table.add_row(s, "Folder")
            else:
                table.add_row(s, "Secret")
        console.print(table)
    except Exception as e:
        console.print(f"[red]Error listing secrets: {e}[/red]")

@secretsmanager.command("put-secret-value")
@click.argument("secret-id")
@click.argument("secret-string")
def secrets_put(secret_id, secret_string):
    """Create or update a secret. Format secret-string as JSON: '{"key":"value"}'."""
    client = get_client()
    try:
        data = json.loads(secret_string)
        client.secrets.kv.v2.create_or_update_secret(path=secret_id, secret=data, mount_point="secret")
        console.print(f"[green]Successfully saved secret to '{secret_id}'.[/green]")
    except json.JSONDecodeError:
        console.print("[red]Error: secret-string must be valid JSON (e.g., '{\"password\": \"12345\"}').[/red]")
    except Exception as e:
        console.print(f"[red]Error saving secret: {e}[/red]")

@secretsmanager.command("get-secret-value")
@click.argument("secret-id")
@click.option("--raw", is_flag=True, help="Print raw JSON output without UI formatting.")
def secrets_get(secret_id, raw):
    """Retrieve a stored secret."""
    client = get_client()
    try:
        response = client.secrets.kv.v2.read_secret_version(path=secret_id, mount_point="secret", raise_on_deleted_version=False)
        data = response["data"]["data"]
        
        if raw:
            console.print(json.dumps(data, indent=2))
        else:
            table = Table(title=f"Secret: {secret_id}")
            table.add_column("Key", style="cyan", justify="right")
            table.add_column("Value", style="green")
            for k, v in data.items():
                table.add_row(str(k), str(v))
            console.print(table)
    except Exception as e:
        console.print(f"[red]Error retrieving secret: {e}[/red]")


# ==============================================================================
# Ultra Secure Secrets (KMS + KV Combined)
# ==============================================================================

@cli.group()
def ultra():
    """Commands for Ultra Secure (Double-Encrypted) Secrets."""
    pass

@ultra.command("put-secret")
@click.argument("secret-id")
@click.argument("key-id")
@click.argument("secret-value")
def ultra_put(secret_id, key_id, secret_value):
    """Store an ultra secret, double-encrypted using the provided KMS key-id."""
    client = get_client()
    path = "ultra/" + secret_id.strip('/')
    
    try:
        # 1. Encrypt with Transit
        encoded = base64.b64encode(secret_value.encode()).decode()
        response = client.secrets.transit.encrypt_data(name=key_id, plaintext=encoded)
        ciphertext = response["data"]["ciphertext"]
        
        # 2. Save to KV
        data = {
            "key": "secret_data",
            "encrypted_value": ciphertext,
            "kms_key_used": key_id
        }
        client.secrets.kv.v2.create_or_update_secret(path=path, secret=data, mount_point="secret")
        console.print(f"[green]Successfully double-encrypted and saved to '{path}'.[/green]")
    except Exception as e:
        console.print(f"[red]Error saving ultra secret: {e}[/red]")

@ultra.command("get-secret")
@click.argument("secret-id")
def ultra_get(secret_id):
    """Retrieve and dynamically decrypt an ultra secret."""
    client = get_client()
    path = "ultra/" + secret_id.strip('/')
    
    try:
        # 1. Read from KV
        response = client.secrets.kv.v2.read_secret_version(path=path, mount_point="secret", raise_on_deleted_version=False)
        data = response["data"]["data"]
        
        ciphertext = data.get("encrypted_value")
        kms_key = data.get("kms_key_used")
        
        if not ciphertext or not kms_key:
            console.print("[red]Error: Data at path is not formatted as an Ultra Secret.[/red]")
            return
            
        # 2. Decrypt with Transit
        dec_response = client.secrets.transit.decrypt_data(name=kms_key, ciphertext=ciphertext)
        encoded_plain = dec_response["data"]["plaintext"]
        plaintext = base64.b64decode(encoded_plain).decode()
        
        panel = Panel(
            f"[bold green]{plaintext}[/bold green]",
            title=f"Decrypted via KMS Key: {kms_key}",
            expand=False
        )
        console.print(panel)
    except Exception as e:
        console.print(f"[red]Error retrieving ultra secret: {e}[/red]")

if __name__ == "__main__":
    cli()